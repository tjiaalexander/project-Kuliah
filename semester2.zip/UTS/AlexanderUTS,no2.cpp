#include<iostream>
using namespace std;

int main(){
   int x,y;
   cout<<"Absis: ";cin>>x;
   cout<<"Ordinat: ";cin>>y;

   cout<<endl;

   if (x>0 and y>0)
    {
    cout<<"Kuadran 1"<<endl;
    }
   else if(x<0 and y>0)
    {
    cout<<"Kuadran 2"<<endl;
    }
   else if(x<0 and y<0)
    {
    cout<<"Kuadran 3"<<endl;
    }
   else if (x>0 and y<0)
    {
    cout<<"Kuadran 4"<<endl;
    }
    return 0;
}
