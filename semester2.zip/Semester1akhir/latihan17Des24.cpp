#include <iostream>
#include <string>
using namepace std;

struct mahasiswa{
    string nama;
    string nim;
    float ipk;
}
int main (){
    void isiData(record A[],int *n);
    void printData(record A[], int n);
    void sortNIM (record A[], int n);
    void sortNama (record A[], int n);
    cout << "Program Array Integer" << endl;
    redMhs data [10];
    int jml;
    isiData(data,&jml);
    printData(Data)
