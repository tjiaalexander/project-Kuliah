//title : bermain 2 bilangan
//modify : 12 maret 2025 by Alexander

#include<iostream>
using namespace std;
//declare
int A, B, wadah;
//describe
main(){
    cout<<"MASUKKAN 2 BILANGAN..."<<endl;
    cout<<"A: ";cin>>A;
    cout<<"B: ";cin>>B;
    cout<<"Bilangan A adalah "<<A<<endl;
    cout<<"Bilangan B adalah "<<B<<endl;

    wadah=A;
    A=B;
    B=wadah;

    cout<<"\n";

    cout<<A<<endl;
    cout<<B<<endl;

}
