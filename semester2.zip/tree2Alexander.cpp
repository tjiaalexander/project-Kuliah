// judul : tree array nomor sepatu tanpa urutan (non-BST)
// author : ifan rizqa (modifikasi by ChatGPT)
// memo : struktur tree array biasa tanpa sorting atau binary logic

#include <iostream>
using namespace std;

// kamus
const int MAX = 31; // Maksimum node dalam array tree
int tree[MAX];      // Array untuk menyimpan data tree
int jumlahNode = 0; // Menghitung banyak node yang dimasukkan

// Fungsi menyisipkan data ke tree secara berurutan
void insert(int value) {
    if (jumlahNode >= MAX) {
        cout << "❌ Tree penuh, tidak bisa menambah data.\n";
        return;
    }

    tree[jumlahNode] = value;
    jumlahNode++; // Tambah jumlah node setelah input
}

// Fungsi menampilkan isi tree (tidak terurut)
void tampilkanTree() {
    for (int i = 0; i < jumlahNode; ++i) {
        cout << tree[i] << " ";
    }
    cout << endl;
}

// program utama
int main() {
    char lagi;

    do {
        int nomor;
        cout << "Masukkan nomor sepatu: ";
        cin >> nomor;
        insert(nomor);

        cout << "Apakah ingin menambah data lagi? (Y/T): ";
        cin >> lagi;

    } while (lagi == 'Y' || lagi == 'y');

    // Tampilkan isi tree sesuai urutan input (tidak terurut)
    cout << "\nNomor sepatu yang dimasukkan (tidak terurut): ";
    tampilkanTree();

    return 0;
}

