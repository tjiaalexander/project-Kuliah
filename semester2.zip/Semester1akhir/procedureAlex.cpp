#include <iostream>
using namespace std;
int main (){
    void hello(string nama);
    string nama_mhs;
    cout<<"Isikan nama: ";cin>>nama_mhs;
    hello(nama_mhs);
    return 0;
}
void hello(string nama){
    cout<<"Halo selamat sore "<<nama<<endl;
    cout<<"================="<<endl;
}
