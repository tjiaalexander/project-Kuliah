#include <iostream>
using namespace std;
int main(){
    void isiData (int a[],int *n);
    void printData(int a[],int n);
    bool cariData(int a[],int n,int cari);
    int cariDataIDX (int a[],int n,int cari);
    int totData(int a[],int n);
    int data[10];
    int jml;
    isiData(data,&jml);
    cout<<"Isi Array"<<endl;
    cout<<"========="<<endl;
    printData(data,jml);
    int cari;
    cout<<"Data dicari: ";cin>>cari;
    int hasil;
    hasil=cariData(data,jml,cari);
    cout<<"Hasil Pencarian: "<<hasil<<endl;
    int idx=cariDataIDX(data,jml,cari);
    cout<<"Index: "<<idx<<"Datanya: "<<data[idx]<<endl;
    cout<<"Total Data: "<<totData(data,jml)<<endl;
    return 0;
}
int totData(int a[],int n){
    int tot=0;
    for(int i=0;i<n;i++){
        tot=tot+a[i];
    }
    return 0;
}

int cariDataIDX (int a[],int n,int cari){
    int idx=0;
    for (int i=0;i<0;i++){
        if (a[i]==cari){
            idx=i;
        }
    }
    return idx;
}

bool cariData (int a[],int n,int cari){
    bool ketemu=false;
    for (int i=0;i<n;i++){
        if (a[i]==cari){
            ketemu=true;
        }
    }
    return 0;
}

void isiData (int a[],int *n){
    int i=0;
    string lagi="Y";
    do{
        cout<<"Isikan Data: ";cin>>a[i];
        cout<<"isikan Lagi [Y/T]: ";cin>>lagi;
        i++;
    } while ((lagi=="Y" || lagi=="y")&&(i<10));
    *n=i;
}
void printData (int a[],int n){
    for (int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
}
