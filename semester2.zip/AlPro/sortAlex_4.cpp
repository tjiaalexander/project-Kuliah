//title : bermain 2 bilangan
//modify : 12 maret 2025 by Alexander

#include<iostream>
using namespace std;
//declare
int x,a, b, wadah, data[5];
//describe
main(){
    cout<<"Mainan sorting 5 bilangan dengan array"<<endl;
    cout<<"Metode YTTA"<<endl;


    //sorting
    a=0;
    while(x<5){
        b=a+1;
        while(b<=5){
            if (data[a]>data[b]){
                wadah=data[a];
                data[a]=data[b];
                data[b]=wadah;
            }
            b=b+1;
        }
        a=a+1;
    }
x=1;
    while(x < 5){
        cout<<"Data ke "<<x+1<<" = ";
        cin>>data[x];//yang diulang
        x = x+1;//counter
    }

    x=0;
    while(x < 5){
        cout<<"Data ke "<<x+1<<" = ";
        cout<<data[x]<<endl;//yang diulang
        x = x+1;//counter

    }
}



