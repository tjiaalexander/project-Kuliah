#include<iostream>
using namespace std;

int main(){
    float p,d,lu,luas;
    string ulang;
    const float pi=3.14;

  do{
    cout<<"HITUNG LUAS JANGKAUAN PENYELAM"<<endl;
    cout<<"=============================="<<endl;
    cout<<"Masukkan Panjang Tali: ";cin>>p;
    cout<<"Masukkan Kedalaman Laut: ";cin>>d;

    cout<<endl;

    if(p<=d)
    {
        cout<<"PERHITUNGAN TIDAK VALID!"<<endl;
    }

    else
    {
    luas=pi*(p*p-d*d);
    cout<<"Luas Jangkauan Penyelam: "<<luas<<endl;
    cout<<"Ulang [Y/T]: ";cin>>ulang;
    }
  }
    while
        (ulang=="Y" || ulang=="y");
            cout<<"Selesai..."<<endl;

        return 0;
  }
