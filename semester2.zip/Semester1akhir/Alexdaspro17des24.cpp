#include <iostream>
#include <string>
#include <vector>
#include <algorithm> // Untuk std::sort
using namespace std;

// Struktur data untuk menyimpan NIM dan Nama
struct Mahasiswa {
    string nama;
    int nim;
};

// Fungsi untuk menukar dua elemen Mahasiswa
void tukar(Mahasiswa &a, Mahasiswa &b) {
    Mahasiswa temp = a;
    a = b;
    b = temp;
}

// Bubble Sort untuk mengurutkan data berdasarkan NIM
void sort_by_nim(vector<Mahasiswa> &list_mhs) {
    int n = list_mhs.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (list_mhs[j].nim > list_mhs[j + 1].nim) {
                tukar(list_mhs[j], list_mhs[j + 1]);
            }
        }
    }
}

// Bubble Sort untuk mengurutkan data berdasarkan Nama
void sort_by_name(vector<Mahasiswa> &list_mhs) {
    int n = list_mhs.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (list_mhs[j].nama > list_mhs[j + 1].nama) {
                tukar(list_mhs[j], list_mhs[j + 1]);
            }
        }
    }
}

// Fungsi untuk mencari data berdasarkan NIM
bool cari_by_nim(const vector<Mahasiswa> &list_mhs, int cari_nim) {
    for (const auto &mhs : list_mhs) {
        if (mhs.nim == cari_nim) {
            cout << "Nama: " << mhs.nama << ", NIM: " << mhs.nim << endl;
            return true;
        }
    }
    return false;
}

// Fungsi untuk mencari data berdasarkan Nama
bool cari_by_name(const vector<Mahasiswa> &list_mhs, const string &cari_nama) {
    for (const auto &mhs : list_mhs) {
        if (mhs.nama == cari_nama) {
            cout << "Nama: " << mhs.nama << ", NIM: " << mhs.nim << endl;
            return true;
        }
    }
    return false;
}

// Fungsi untuk mengisi data mahasiswa
void isi_data(vector<Mahasiswa> &list_mhs) {
    char ulang = 'y';
    while (ulang == 'y') {
        Mahasiswa mhs;
        cout << "Masukkan NIM mahasiswa: ";
        cin >> mhs.nim;
        cin.ignore(); // Membersihkan buffer
        cout << "Masukkan Nama mahasiswa: ";
        getline(cin, mhs.nama);
        list_mhs.push_back(mhs);
        cout << "Ingin menambah data lagi? (y/t): ";
        cin >> ulang;
        cin.ignore();
    }
}

// Fungsi untuk mencetak data mahasiswa
void print_data(const vector<Mahasiswa> &list_mhs) {
    cout << "Daftar Mahasiswa:\n";
    for (size_t i = 0; i < list_mhs.size(); i++) {
        cout << i + 1 << ". NIM: " << list_mhs[i].nim << ", Nama: " << list_mhs[i].nama << endl;
    }
}

// Fungsi Bubble Sort untuk array angka
void bubblesort(vector<int> &A) {
    int n = A.size();
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (A[j] > A[j + 1]) {
                swap(A[j], A[j + 1]);
            }
        }
    }
}

int main() {
    vector<Mahasiswa> list_mhs;
    int pilihan;

    do {
        // Menu
        cout << "\nMenu:\n";
        cout <<"==========\n";
        cout << "1. Isi Data\n";
        cout << "2. Print Data\n";
        cout << "3. Cari Data Berdasarkan NIM\n";
        cout << "4. Cari Data Berdasarkan Nama\n";
        cout << "5. Sorting Berdasarkan NIM\n";
        cout << "6. Sorting Berdasarkan Nama\n";
        cout << "7. Print Jumlah Data\n";
        cout << "8. Sortir Angka\n";
        cout << "9. Selesai\n";
        cout << "Pilih opsi (1-9): ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                isi_data(list_mhs);
                break;
            case 2:
                if (!list_mhs.empty())
                    print_data(list_mhs);
                else
                    cout << "Data mahasiswa kosong.\n";
                break;
            case 3: {
                int cari_nim;
                cout << "Masukkan NIM yang dicari: ";
                cin >> cari_nim;
                if (!cari_by_nim(list_mhs, cari_nim)) {
                    cout << "NIM " << cari_nim << " tidak ditemukan.\n";
                }
                break;
            }
            case 4: {
                string cari_nama;
                cin.ignore();
                cout << "Masukkan Nama yang dicari: ";
                getline(cin, cari_nama);
                if (!cari_by_name(list_mhs, cari_nama)) {
                    cout << "Nama " << cari_nama << " tidak ditemukan.\n";
                }
                break;
            }
            case 5:
                if (!list_mhs.empty()) {
                    sort_by_nim(list_mhs);
                    cout << "Data berhasil diurutkan berdasarkan NIM.\n";
                } else {
                    cout << "Data mahasiswa kosong.\n";
                }
                break;
            case 6:
                if (!list_mhs.empty()) {
                    sort_by_name(list_mhs);
                    cout << "Data berhasil diurutkan berdasarkan Nama.\n";
                } else {
                    cout << "Data mahasiswa kosong.\n";
                }
                break;
            case 7:
                cout << "Jumlah data: " << list_mhs.size() << " mahasiswa\n";
                break;
            case 8: {
                int n;
                cout << "Masukkan Jumlah Array: ";
                cin >> n;
                vector<int> A(n);

                for (int i = 0; i < n; i++) {
                    cout << "Elemen ke-" << i + 1 << ": ";
                    cin >> A[i];
                }

                cout << "Array sebelum sorting: ";
                for (int num : A) cout << num << " ";
                cout << endl;

                bubblesort(A);

                cout << "Array setelah sorting: ";
                for (int num : A) cout << num << " ";
                cout << endl;
                break;
            }
            case 9:
                cout << "Program Selesai.\n";
                break;
            default:
                cout << "Pilihan tidak valid. Silakan coba lagi.\n";
        }
    } while (pilihan != 9);

    return 0;
}
