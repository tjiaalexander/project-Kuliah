#include <iostream>
using namespace std;

// Struktur node
struct Node {
    int data;
    Node* next;
};

void insertEnd(Node*& head, int value) {
    Node* newNode = new Node{value, nullptr};

    if (head == nullptr) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != nullptr)
            temp = temp->next;
        temp->next = newNode;
    }
}

void tampilkan(Node* head) {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

void urutkan(Node* head, bool ascending) {
    if (head == nullptr) return;

    for (Node* i = head; i->next != nullptr; i = i->next) {
        for (Node* j = i->next; j != nullptr; j = j->next) {
            if ((ascending && i->data > j->data) || (!ascending && i->data < j->data)) {
                int temp = i->data;
                i->data = j->data;
                j->data = temp;
            }
        }
    }
}

int main() {
    Node* head = nullptr;
    int value;
    int pilihan;

    cout << "Masukkan 3 bilangan:" << endl;
    for (int i = 0; i < 3; i++) {
        cout << "Bilangan ke-" << i + 1 << ": ";
        cin >> value;
        insertEnd(head, value);
    }

    cout << "\nLinked list sebelum diurutkan: ";
    tampilkan(head);


    cout << "\nPilih mau di urutkan dari mana:\n";
    cout << "1. Ascending \n";
    cout << "2. Descending \n";
    cout << "Pilihan Anda: ";
    cin >> pilihan;

    bool ascending = (pilihan == 1);
    urutkan(head, ascending);

    cout << endl;

    cout << "Linked list sesudah diurutkan: ";
    tampilkan(head);

    return 0;
}
