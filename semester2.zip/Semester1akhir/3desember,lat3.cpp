#include<iostream>
using namespace std;
int main(){
    void isiData (int a[],int *n);
    void printData(int a[],int n);
    int data [10];
    int jmlh;
    isiData(data,&jmlh);
    cout<<"Isi Array: "<<endl;
    cout<<"==========="<<endl;
    printData(data,jmlh);
    return 0;
}
void isiData (int a[],int *n){
    int i=0;
    string lagi="Y";
    do{
    cout<<"Isikan data:";cin>>a[i];
    cout<<"Isikan lagi [Y/T]:";cin>>lagi;
    i++;
    }while ((lagi=="Y"||lagi=="y")&&(i<10));
    *n=i;
}
void printData(int a[],int n){
    for (int i=0;i<n;i++){
        cout<<a[i]<<" ";
    }
}
void cariData(int a[],int n,int cari){
    bool ketemu=false;
    for(int i=0;i<n;i++){
        if (a[i]==cari){
            ketemu==true;
        }
    }
    if(ketemu==true){
        cout<<"Data Ditemukan..."<<endl;
    }else{
        cout<<"Data Tidak Ditemukan.."<<endl;
    }
}
void dataTerbesar (int a[],int n,int &max){
    max = a[0];
    for (int i=1;i<n;i++){
        if(a[i]>max){

        }
    }
    cout<<"Data Terbesar: "<<max<<endl;
}
