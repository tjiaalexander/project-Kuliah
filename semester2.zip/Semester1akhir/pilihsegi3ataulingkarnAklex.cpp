#include <iostream>
#include<cmath>
using namespace std;
int main (){
    void hitungLuasLingkaran();
    void hitungLuasSegi3();
    int pilih;
    cout<<"1. Luas Lingkaran & 2. Luas Segitiga"<<endl;
    cout<<"Pilih: ";cin>>pilih;
    if (pilih==1){
        hitungLuasLingkaran();
    }
    else if (pilih==2){
        hitungLuasSegi3();
    }
    else
        cout<<"salah pilih";
    return 0;
}
void hitungLuasSegi3(){
    int alas,tinggi;
    float luas;
    cout<<"Program Hitung Luas Segitiga"<<endl;
    cout<<"============================"<<endl;
    cout<<"Masukkan alas: ";cin>>alas;
    cout<<"Masukkan tinggi: ";cin>>tinggi;
    luas=(alas*tinggi)/2.0;
    cout<<"Luas: "<<luas<<endl;
}
void hitungLuasLingkaran(){
      const float pi=3.14;
    int r;
    float luas;
    cout<<"Program Hitung Luas Lingkaran"<<endl;
    cout<<"============================"<<endl;
    cout<<"Masukkan r: ";cin>>r;
    luas=pi*pow(r,2);
    cout<<"Luas: "<<luas<<endl;
}

