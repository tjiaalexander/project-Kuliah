#include <iostream>
using namespace std;

// ================================
// 1. Pendataan dengan variabel biasa
// ================================
void variabelBiasa() {
    cout << "\n[1] Pendataan nomor sepatu dengan variabel biasa" << endl;
    int sepatu1 = 39;
    int sepatu2 = 40;
    int sepatu3 = 41;

    cout << "Nomor sepatu: " << sepatu1 << ", " << sepatu2 << ", " << sepatu3 << endl;
}

// ================================
// 2. Pendataan dengan array
// ================================
void arrayLarik() {
    cout << "\n[2] Pendataan nomor sepatu dengan array" << endl;
    int sepatu[3] = {39, 40, 41};

    for (int i = 0; i < 3; i++) {
        cout << "Nomor sepatu ke-" << i + 1 << ": " << sepatu[i] << endl;
    }
}

// ================================
// 3. Singly Linked List
// ================================
struct Node {
    int data;
    Node* next;
};

void linkedList() {
    cout << "\n[3] Pendataan nomor sepatu dengan Linked List" << endl;
    Node* head = new Node{39, nullptr};
    head->next = new Node{40, nullptr};
    head->next->next = new Node{41, nullptr};

    Node* current = head;
    while (current != nullptr) {
        cout << "Nomor sepatu: " << current->data << endl;
        current = current->next;
    }

    // Hapus memori
    current = head;
    while (current != nullptr) {
        Node* temp = current;
        current = current->next;
        delete temp;
    }
}

// ================================
// 4. Doubly Linked List
// ================================
struct DNode {
    int data;
    DNode* prev;
    DNode* next;
};

void doubleLinkedList() {
    cout << "\n[4] Pendataan nomor sepatu dengan Double Linked List" << endl;
    DNode* node1 = new DNode{39, nullptr, nullptr};
    DNode* node2 = new DNode{40, node1, nullptr};
    DNode* node3 = new DNode{41, node2, nullptr};
    node1->next = node2;
    node2->next = node3;

    DNode* current = node1;
    while (current != nullptr) {
        cout << "Nomor sepatu: " << current->data << endl;
        current = current->next;
    }

    // Hapus memori
    current = node3;
    while (current != nullptr) {
        DNode* temp = current;
        current = current->prev;
        delete temp;
    }
}

// ================================
// 5. Circular Linked List
// ================================
struct CNode {
    int data;
    CNode* next;
};

void circularLinkedList() {
    cout << "\n[5] Pendataan nomor sepatu dengan Circular Linked List" << endl;
    CNode* node1 = new CNode{39, nullptr};
    CNode* node2 = new CNode{40, nullptr};
    CNode* node3 = new CNode{41, nullptr};

    // Sambungkan node
    node1->next = node2;
    node2->next = node3;
    node3->next = node1; // Circular link

    // Menampilkan isi (1 putaran)
    CNode* current = node1;
    int count = 0;
    do {
        cout << "Nomor sepatu: " << current->data << endl;
        current = current->next;
        count++;
    } while (current != node1 && count < 10);

    // Hapus memori (karena circular, kita harus hati-hati)
    current = node1->next;
    delete node1;
    while (current != node1) {
        CNode* temp = current;
        current = current->next;
        delete temp;
    }
}

// ================================
// Program Utama
// ================================
int main() {
    variabelBiasa();
    arrayLarik();
    linkedList();
    doubleLinkedList();
    circularLinkedList();

    return 0;
}
