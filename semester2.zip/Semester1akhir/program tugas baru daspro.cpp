#include <iostream>
using namespace std;

void isiDataArray(int data[], int &jumlah);
void cetakDataArray(int data[], int jumlah);
void cariData(int data[], int jumlah);
void printMax(int data[], int jumlah);
void printMin(int data[], int jumlah);
void printAverage(int data[], int jumlah);
void printTotal(int data[], int jumlah);

int main() {
    int data[100];
    int jumlah = 0;
    int pilihan;

    do {
        cout << "\n ===MENU=== \n";
        cout << "1. Isi Data Array\n";
        cout << "2. Cetak Data Array\n";
        cout << "3. Cari Data\n";
        cout << "4. Cetak Max\n";
        cout << "5. Cetak Min\n";
        cout << "6. Cetak Average\n";
        cout << "7. Cetak Total\n";
        cout << "8. Keluar\n";
        cout<<endl;
        cout << "Pilih menu: ";
        cin >> pilihan;


        switch (pilihan) {
            case 1:
                isiDataArray(data, jumlah);
                break;
            case 2:
                cetakDataArray(data, jumlah);
                break;
            case 3:
                cariData(data, jumlah);
                break;
            case 4:
                printMax(data, jumlah);
                break;
            case 5:
                printMin(data, jumlah);
                break;
            case 6:
                printAverage(data, jumlah);
                break;
            case 7:
                printTotal(data, jumlah);
                break;
            case 8:
                cout << "Keluar dari program.\n";
                break;
            default:
                cout << "Pilihan tidak valid.\n";
        }
    } while (pilihan != 8);

    return 0;
}
void isiDataArray(int data[], int &jumlah) {
    cout << "Jumlah Data? ";
    cin >> jumlah;

    for (int i = 0; i < jumlah; i++) {
        cout << "Masukkan data ke-" << (i + 1) << ": ";
        cin >> data[i];
    }
}
void cetakDataArray(int data[], int jumlah) {
    if (jumlah == 0) {
        cout << "Array kosong!\n";
        return;
    }
    cout << "\nData dalam array:\n";
    for (int i = 0; i < jumlah; i++) {
        cout << "Data ke-" << (i + 1) << ": " << data[i] << endl;
    }
}
void cariData(int data[], int jumlah) {
    if (jumlah == 0) {
        cout << "Array kosong!\n";
        return;
    }
    int cari;
    cout << "Masukkan data: ";
    cin >> cari;

    bool ditemukan = false;
    for (int i = 0; i < jumlah; i++) {
        if (data[i] == cari) {
            cout << "Indeks ke-" << i << endl;
            ditemukan = true;
        }
    }
    if (!ditemukan) {
        cout << "Data tidak ditemukan.\n";
    }
}
void printMax(int data[], int jumlah) {
    if (jumlah == 0) {
        cout << "Array kosong!\n";
        return;
    }
    int max = data[0];
    for (int i = 1; i < jumlah; i++) {
        if (data[i] > max) {
            max = data[i];
        }
    }
    cout << "Nilai maksimum: " << max << endl;
}
void printMin(int data[], int jumlah) {
    if (jumlah == 0) {
        cout << "Array kosong!\n";
        return;
    }
    int min = data[0];
    for (int i = 1; i < jumlah; i++) {
        if (data[i] < min) {
            min = data[i];
        }
    }
    cout << "Nilai minimum: " << min << endl;
}
void printAverage(int data[], int jumlah) {
    if (jumlah == 0) {
        cout << "Array kosong!\n";
        return;
    }
    int total = 0;
    for (int i = 0; i < jumlah; i++) {
        total += data[i];
    }
    double rata2 = static_cast<double>(total) / jumlah;
    cout << "Rata-rata nilai: " << rata2 << endl;
}
void printTotal(int data[], int jumlah) {
    if (jumlah == 0) {
        cout << "Array kosong!\n";
        return;
    }
    int total = 0;
    for (int i = 0; i < jumlah; i++) {
        total += data[i];
    }
    cout << "Total nilai: " << total << endl;
}
