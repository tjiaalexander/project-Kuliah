function hitungHasil(){
    let saldoAwal=parseInt(document.getElementById('saldoAwal').value)
    let hutang=parseInt(document.getElementById('hutang').value)
    let sisaSaldo=saldoAwal-hutang

    hasil.textContent="Sisa Saldo Rp."+sisaSaldo
}

function cetakHarga(){
    let hargaPerliter=parseInt(document.getElementById('hargaPerliter').value)
    let totalLiter=parseInt(document.getElementById('totalLiter').value)

    let tabelAwal=" <table border=1> \
                <tr> \
                    <td>Liter</td> \
                    <td>Harga Perliter</td>  \
                    <td>Total Harga</td> \
                </tr>"
            
    let tabelIsi=' '
    for (let liter=1;liter<=totalLiter;liter++){
        tabelIsi=tabelIsi+"<tr> \
                    <td>"+liter+"</td> \
                    <td>"+hargaPerliter+"</td> \
                    <td>"+(liter*hargaPerliter)+"</td> \
                </tr>"
    }
   console.log(tabelIsi)
    let tabelAkhir="</table>"
    let tabelHitung=tabelAwal+tabelIsi+tabelAkhir

    cetakTabel.outerHTML=tabelHitung
    tabel.innerHTML = rows
}