//belajar variabel
let nama='UDINUS'
let umur=50
let tinggi=170.5

console.log('mendefinisikan variabel...')


alert('Selamat Datang di UDINUS')
alert ('Selamat Datang '+nama+' umur anda '+umur,' tahun, tinggi anda '+tinggi+'cm')


let saldo_awal = 100000
let tambahan = 75000
let hutang = 25000
let total_saldo = saldo_awal+tambahan-hutang
alert (`Saldo awal Rp.${saldo_awal} tambahan Rp.${tambahan} hutang Rp.${hutang} Total Saldo Rp.${total_saldo}`)

console.log('Operasi Variabel...'+saldo_awal)

//perulangan
console.log('Udinus')

for (let x=1;x<10;x++){
    console.log('Semarang')
}

let turbo=140000
for(let y=1;y<=100;y++){
    console.log(y+'Liter ='+turbo*y)
}

for(let angka=1;angka<=10;angka++){
    if (angka == 3){
        console.log('Tiga')
    } else if (angka == 7) {
        console.log('Tujuh')
    } else {
        console.log(angka)
    }
}

function ubahText(){
    btn2.textContent="Saya dilewati..."
}

function textOri(){
    btn2.textContent="Tombol 2"
}
