let cart = [];

// Ambil elemen DOM
const cartCountElement = document.getElementById("cart-count");
const cartTotalElement = document.getElementById("cart-total");
const addToCartButtons = document.querySelectorAll(".add-to-cart");

// Fungsi untuk memperbarui keranjang
function updateCart() {
    const totalItems = cart.length;
    const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

    // Perbarui elemen DOM
    cartCountElement.textContent = totalItems;
    cartTotalElement.textContent = "Rp " + totalPrice.toLocaleString();
}

// Tambahkan event listener ke setiap tombol
addToCartButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const productName = button.getAttribute("data-product");
        const productPrice = parseInt(button.getAttribute("data-price"));

        // Tambahkan produk ke keranjang
        cart.push({ name: productName, price: productPrice });

        // Perbarui tampilan keranjang
        updateCart();
    });
});
