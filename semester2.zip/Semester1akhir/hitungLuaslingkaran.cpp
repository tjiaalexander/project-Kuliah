#include <iostream>

using namespace std;
const float pi=3.14;
int main (){
    void hitungLuasLingkaran();
    hitungLuasLingkaran();
    return 0;
}
void hitungLuasLingkaran(){
    int r;
    float luas;
    cout<<"Program Hitung Luas Lingkaran"<<endl;
    cout<<"============================"<<endl;
    cout<<"Masukkan r: ";cin>>r;
#include <cmath>    luas=pi*pow(r,2);
    cout<<"Luas: "<<luas<<endl;
}
