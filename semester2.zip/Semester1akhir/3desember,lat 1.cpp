#include<iostream>
using namespace std;
int z=8;

int main(){
    void add(int a);
    int x=10;
    cout<<"x="<<x<<endl;
    add(x);
    return 0;
}

void add(int a){
    a=a*10;
    cout<<"a="<<a<<endl;
    cout<<"z="<<z<<endl;
}
