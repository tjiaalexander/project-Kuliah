//title : bermain 2 bilangan
//modify : 12 maret 2025 by Alexander

#include<iostream>
using namespace std;
//declare
int A, B, wadah;
//describe
main(){
    cout<<"MASUKKAN 2 BILANGAN..."<<endl;
    cout<<"A: ";cin>>A;
    cout<<"B: ";cin>>B;
    cout<<"Bilangan A adalah "<<A<<endl;
    cout<<"Bilangan B adalah "<<B<<endl;

    if (A>B){
        cout<<"Nilai A yaitu "<<A<<" lebih besar dari B yaitu "<<B<<endl;
    }
    else if (B>A){
            cout<<"Nilai B yaitu "<<B<<" lebih besar dari A yaitu "<<A<<endl;
    }
    else{
        cout<<"Nilai A yaitu "<<A<<" sama dengan nilai B yaitu "<<B<<endl;
    }
}
