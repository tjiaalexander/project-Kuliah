#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

class Buku {
public:
    string nama;
    float panjang, lebar, luas;
    int harga, jumlahHalaman;

    Buku() {}
    Buku(string n, float p, float l, int h, int jh) {
        nama = n;
        panjang = p;
        lebar = l;
        harga = h;
        jumlahHalaman = jh;
        hitungLuas();
    }

    void hitungLuas() {
        luas = panjang * lebar;
    }

    float getLuas() const { return luas; }
    string getNama() const { return nama; }

    void tampilkanLuas() const {
        cout << "Nama: " << nama << ", Luas: " << luas << " cm�" << endl;
    }
};

// Struct untuk Node Linked List
struct Node {
    Buku data;
    Node* next;
};

// Fungsi umum linked list
void tambahBelakang(Node*& head, Buku dataBuku) {
    Node* baru = new Node{dataBuku, nullptr};
    if (!head) {
        head = baru;
    } else {
        Node* temp = head;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = baru;
    }
}

void tampilkanList(Node* head) {
    if (!head) {
        cout << "Tidak ada data.\n";
        return;
    }
    Node* temp = head;
    while (temp) {
        temp->data.tampilkanLuas();
        temp = temp->next;
    }
}

void search(Node* head, const string& namaCari) {
    Node* temp = head;
    while (temp) {
        if (temp->data.getNama() == namaCari) {
            cout << "Ditemukan! ";
            temp->data.tampilkanLuas();
            return;
        }
        temp = temp->next;
    }
    cout << "Buku dengan nama \"" << namaCari << "\" tidak ditemukan.\n";
}

void sorting(Node*& head) {
    if (!head || !head->next) return;

    bool swapped;
    do {
        swapped = false;
        Node* curr = head;
        while (curr->next) {
            if (curr->data.getNama() > curr->next->data.getNama()) {
                swap(curr->data, curr->next->data);
                swapped = true;
            }
            curr = curr->next;
        }
    } while (swapped);
}

// Stack
class Stack {
private:
    Node* top;
public:
    Stack() : top(nullptr) {}

    void push(Buku buku) {
        Node* baru = new Node{buku, top};
        top = baru;
    }

    void pop() {
        if (!top) {
            cout << "Rak kosong!\n";
            return;
        }
        Node* temp = top;
        cout << "Mengambil buku: " << temp->data.getNama() << endl;
        top = top->next;
        delete temp;
    }

    void tampilkanStack() {
        cout << "== Isi Rak Buku (Stack) ==\n";
        tampilkanList(top);
    }

    ~Stack() {
        while (top) {
            Node* temp = top;
            top = top->next;
            delete temp;
        }
    }
};

// Queue
class Queue {
private:
    Node* front;
    Node* rear;

public:
    Queue() : front(nullptr), rear(nullptr) {}

    void enqueue(Buku buku) {
        Node* baru = new Node{buku, nullptr};
        if (!rear) {
            front = rear = baru;
        } else {
            rear->next = baru;
            rear = baru;
        }
    }

    void dequeue() {
        if (!front) {
            cout << "Antrian kosong!\n";
            return;
        }
        Node* temp = front;
        cout << "Melayani pengunjung: " << temp->data.getNama() << endl;
        front = front->next;
        if (!front) rear = nullptr;
        delete temp;
    }

    void tampilkanQueue() {
        cout << "== Antrean Pengunjung ==\n";
        tampilkanList(front);
    }

    ~Queue() {
        while (front) {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
    }
};

// Fungsi menyimpan data buku ke file
void simpanData(Node* head) {
    ofstream file("daftar_buku.txt");
    if (!file) {
        cout << "Gagal membuka file untuk menyimpan data!\n";
        return;
    }

    Node* temp = head;
    while (temp) {
        file << temp->data.getNama() << "\n"
             << temp->data.panjang << " "
             << temp->data.lebar << " "
             << temp->data.harga << " "
             << temp->data.jumlahHalaman << "\n";
        temp = temp->next;
    }
    file.close();
    cout << "Data berhasil disimpan ke file.\n";
}

// Fungsi membaca data buku dari file
void bacaData(Node*& head) {
    ifstream file("daftar_buku.txt");
    if (!file) {
        cout << "Tidak ada file data yang ditemukan. Memulai dengan daftar kosong.\n";
        return;
    }

    string nama, namaPengunjung;
    float panjang, lebar;
    int harga, halaman;

    while (getline(file, nama)) {
        file >> panjang >> lebar >> harga >> halaman;
        file.ignore();  // mengabaikan newline

        Buku buku(nama, panjang, lebar, harga, halaman);
        tambahBelakang(head, buku);
    }

    file.close();
    cout << "Data berhasil dimuat dari file.\n";
}

// Main
int main() {
    Node* daftarBuku = nullptr;
    Stack rak;
    Queue antrian;

    // Load data dari file saat program mulai
    bacaData(daftarBuku);

    int pilihan;
    do {
        cout << "\n=== Menu Perpustakaan ===\n";
        cout << "1. Tambah Buku ke Daftar\n";
        cout << "2. Tampilkan Daftar Buku\n";
        cout << "3. Masukkan Buku ke Rak (Stack)\n";
        cout << "4. Ambil Buku dari Rak (Stack)\n";
        cout << "5. Tambahkan Pengunjung ke Antrian\n";
        cout << "6. Layani Pengunjung dari Antrian\n";
        cout << "7. Cari Buku\n";
        cout << "8. Urutkan Buku (berdasarkan nama)\n";
        cout << "9. Tampilkan Rak\n";
        cout << "10. Tampilkan Antrian\n";
        cout << "0. Keluar\n";
        cout << "Pilihan: ";
        cin >> pilihan;
        cin.ignore();

        if (pilihan == 1) {
            string nama;
            float panjang, lebar;
            int harga, halaman;
            cout << "Nama Buku: ";
            getline(cin, nama);
            cout << "Panjang (cm): "; cin >> panjang;
            cout << "Lebar (cm): "; cin >> lebar;
            cout << "Harga: "; cin >> harga;
            cout << "Jumlah Halaman: "; cin >> halaman;
            cin.ignore();
            Buku buku(nama, panjang, lebar, harga, halaman);
            tambahBelakang(daftarBuku, buku);
            cout << "Buku ditambahkan!\n";
        } else if (pilihan == 2) {
            tampilkanList(daftarBuku);
        } else if (pilihan == 3) {
            string nama;
            cout << "Masukkan nama buku untuk dimasukkan ke rak: ";
            getline(cin, nama);
            Node* temp = daftarBuku;
            while (temp) {
                if (temp->data.getNama() == nama) {
                    rak.push(temp->data);
                    cout << "Buku dimasukkan ke rak.\n";
                    break;
                }
                temp = temp->next;
            }
            if (!temp) cout << "Buku tidak ditemukan.\n";
        } else if (pilihan == 4) {
            rak.pop();
        } else if (pilihan == 5) {
            string namaPengunjung;
            cout << "Nama Pengunjung : ";
            getline(cin, namaPengunjung);
            antrian.enqueue(Buku(namaPengunjung, 0, 0, 0, 0));
        } else if (pilihan == 6) {
            antrian.dequeue();
        } else if (pilihan == 7) {
            string cari;
            cout << "Masukkan nama buku yang dicari: ";
            getline(cin, cari);
            search(daftarBuku, cari);
        } else if (pilihan == 8) {
            sorting(daftarBuku);
            cout << "Daftar buku berhasil diurutkan.\n";
        } else if (pilihan == 9) {
            rak.tampilkanStack();
        } else if (pilihan == 10) {
            antrian.tampilkanQueue();
        } else if (pilihan == 0) {
            cout << "Terima kasih telah menggunakan sistem.\n";
            simpanData(daftarBuku);
        } else {
            cout << "Pilihan tidak valid!\n";
        }

    } while (pilihan != 0);

    // Hapus memori
    while (daftarBuku) {
        Node* temp = daftarBuku;
        daftarBuku = daftarBuku->next;
        delete temp;
    }

    return 0;
}
