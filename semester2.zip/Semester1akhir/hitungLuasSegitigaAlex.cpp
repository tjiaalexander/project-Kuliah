#include <iostream>
using namespace std;
int main (){
    void hitungLuasSegi3();
    hitungLuasSegi3();
    return 0;
}
void hitungLuasSegi3(){
    int alas,tinggi;
    float luas;
    cout<<"Program Hitung Luas Segitiga"<<endl;
    cout<<"============================"<<endl;
    cout<<"Masukkan alas: ";cin>>alas;
    cout<<"Masukkan tinggi: ";cin>>tinggi;
    luas=(alas*tinggi)/2.0;
    cout<<"Luas: "<<luas<<endl;
}
