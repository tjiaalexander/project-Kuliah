// Judul : Tree dengan array nomor sepatu loop while Y/T
// Author : Ifan Rizqa
// Memo : Silakan dicermati dan perhatikan komentar penting pada baris-baris tertentu

#include <iostream>
using namespace std;

// Konstanta dan variabel global
const int MAX = 31;         // Maksimum jumlah node dalam tree (cukup untuk tree biner hingga level 5)
int tree[MAX];              // Array untuk menyimpan elemen tree
bool filled[MAX];           // Penanda apakah suatu indeks sudah terisi atau belum

// Fungsi untuk menyisipkan nilai ke dalam tree
void insert(int value, int index = 0) {
    if (index >= MAX) {
        // Jika indeks melebihi kapasitas array, tampilkan pesan kesalahan
        cout << "❌ Tree penuh atau indeks melebihi batas.\n";
        return;
    }

    if (!filled[index]) {
        // Jika node pada indeks belum terisi, isi dengan nilai baru
        tree[index] = value;
        filled[index] = true;
    } else if (value > tree[index]) {
        // Jika nilai lebih kecil dari node saat ini, masukkan ke anak kiri
        insert(value, 2 * index + 2);
    } else {
        // Jika nilai lebih besar atau sama, masukkan ke anak kanan
        insert(value, 2 * index + 1);
    }
}

// Fungsi inorder traversal untuk mencetak tree secara urut (dari kecil ke besar)
void inorder(int index = 0) {
    if (index >= MAX || !filled[index]) return;

    inorder(2 * index + 2);         // Kunjungi anak kiri terlebih dahulu
    cout << tree[index] << " ";     // Cetak node saat ini
    inorder(2 * index + 1);         // Kunjungi anak kanan
}

// Fungsi untuk mencari nilai di tree, mengembalikan indeks jika ketemu, -1 jika tidak
int search(int value, int index = 0) {
    if (index >= MAX || !filled[index]) {
        // Jika indeks di luar batas atau posisi kosong, berarti tidak ditemukan
        return -1;
    }
    if (tree[index] == value) {
        // Jika nilai ketemu, kembalikan indeksnya
        return index;
    } else if (value < tree[index]) {
        // Jika nilai yang dicari lebih kecil, cari di anak kiri
        return search(value, 2 * index - 2);
    } else {
        // Jika lebih besar, cari di anak kanan
        return search(value, 2 * index - 1);
    }
}

int main() {
    // Inisialisasi array penanda agar semua indeks dianggap kosong
    for (int i = 0; i < MAX; i++) filled[i] = false;

    char lagi; // Variabel untuk menyimpan input user (apakah ingin lanjut)
    do {
        int nomor;
        cout << "Masukkan nomor sepatu: ";
        cin >> nomor;

        // Sisipkan nomor sepatu ke dalam tree
        insert(nomor);

        // Tanya user apakah ingin memasukkan data lagi
        cout << "Apakah ingin menambah data lagi? (Y/T): ";
        cin >> lagi;
    } while (lagi == 'Y' || lagi == 'y'); // Ulangi jika jawaban 'Y' atau 'y'

    // Tampilkan isi tree setelah dimasukkan semua data (dalam urutan yang benar)
    cout << "\nNomor sepatu setelah disusun (Inorder traversal): ";
    inorder();
    cout << endl;

    // Loop pencarian dengan pertanyaan apakah user mau mencari lagi
    do {
        int cari;
        cout << "Masukkan nomor sepatu yang ingin dicari: ";
        cin >> cari;

        int hasil = search(cari);
        if (hasil == -1) {
            cout << "Nomor sepatu " << cari << " tidak ditemukan di tree.\n";
        } else {
            cout << "Nomor sepatu " << cari << " ditemukan di indeks " << hasil << " pada tree.\n";
        }

        cout << "Apakah ingin mencari nomor sepatu lain? (Y/T): ";
        cin >> lagi;
    } while (lagi == 'Y' || lagi == 'y');

    return 0;
}
