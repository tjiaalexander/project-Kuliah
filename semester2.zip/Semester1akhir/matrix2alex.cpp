#include <iostream>
using namespace std;
int main (){
    //matrix ordo 3x4
    int A[][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12}};
    int B[][4]={{1,1,1,1},{1,1,1,1},{1,1,1,1}};
    int C[3][4];
    //cout<<"A[0][0]: "<<A[0][0]<<endl;
    for (int i=0;i<3;i++){
        for (int j=0;j<4;j++){
            A[i][j];
            B[i][j]=A[i][j]*2;
            C[i][j]=A[i][j]+B[i][j];
        }
    }
    for (int i=0;i<3;i++){
        for (int j=0;j<4;j++){
            cout<<A[i][j]<<"\t"; cout<<endl;
             cout<<C[i][j]<<"\t"; cout<<endl;
              cout<<C[i][j]<<"\t";
        }
        cout<<endl;
    }
    return 0;
}
