#include <iostream>
using namespace std;

struct Kartu {
    string nama;
    int no;
    Kartu* next;
};

// Tambah node di belakang
void tambahNode(Kartu*& head, string nama, int no) {
    Kartu* newNode = new Kartu{nama, no, nullptr};
    if (head == nullptr) {
        head = newNode;
    } else {
        Kartu* temp = head;
        while (temp->next != nullptr)
            temp = temp->next;
        temp->next = newNode;
    }
}

// Tambah node di depan
void tambahDepan(Kartu*& head, string nama, int no) {
    Kartu* newNode = new Kartu{nama, no, head};
    head = newNode;
}

// Tambah node di tengah
void tambahTengah(Kartu*& head, string nama, int no, int posisi) {
    if (posisi <= 1 || head == nullptr) {
        tambahDepan(head, nama, no);
        return;
    }
    Kartu* temp = head;
    for (int i = 1; i < posisi - 1; i++) {
        if (temp->next == nullptr) {
            cout << "Posisi tidak ditemukan" << endl;
            return;
        }
        temp = temp->next;
    }
    Kartu* newNode = new Kartu{nama, no, temp->next};
    temp->next = newNode;
}

// Hapus node berdasarkan nama dan no
void hapus(Kartu*& head, string nama, int no) {
    if (head == nullptr) {
        cout << "Linked list kosong\n";
        return;
    }

    if (head->nama == nama && head->no == no) {
        Kartu* temp = head;
        head = head->next;
        delete temp;
        cout << "Data " << nama << " berhasil dihapus\n";
        return;
    }

    Kartu* current = head;
    while (current->next != nullptr &&
           !(current->next->nama == nama && current->next->no == no)) {
        current = current->next;
    }

    if (current->next != nullptr) {
        Kartu* temp = current->next;
        current->next = temp->next;
        delete temp;
        cout << "Data " << nama << " berhasil dihapus\n";
    } else {
        cout << "Data tidak ditemukan\n";
    }
}

// Sorting berdasarkan no (ascending atau descending)
void sorting(Kartu*& head, bool ascending = true) {
    if (head == nullptr || head->next == nullptr) return;

    bool swapped;
    do {
        swapped = false;
        Kartu* current = head;
        while (current->next != nullptr) {
            if ((ascending && current->no > current->next->no) ||
                (!ascending && current->no < current->next->no)) {
                swap(current->nama, current->next->nama);
                swap(current->no, current->next->no);
                swapped = true;
            }
            current = current->next;
        }
    } while (swapped);
}

// Cari node berdasarkan nama dan no
void cari(Kartu* head, string nama, int no) {
    Kartu* temp = head;
    while (temp != nullptr) {
        if (temp->nama == nama && temp->no == no) {
            cout << "Data ditemukan: " << nama << " - " << no << endl;
            return;
        }
        temp = temp->next;
    }
    cout << "Data tidak ditemukan\n";
}

// Tampilkan isi linked list
void tampilkan(Kartu* head) {
    if (head == nullptr) {
        cout << "Linked list kosong\n";
        return;
    }

    Kartu* temp = head;
    cout << "Isi linked list:\n";
    while (temp != nullptr) {
        cout << temp->nama << " (" << temp->no << ") -> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

int main() {
    Kartu* head = nullptr;

    // Tambah data awal
    tambahNode(head, "Andi", 21);
    tambahNode(head, "Budi", 35);
    tambahNode(head, "Cici", 18);
    tambahNode(head, "Dina", 28);
    tambahNode(head, "Eka", 25);

    return 0;
}
