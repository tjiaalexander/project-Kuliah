function generateTable() {
    // Ambil nilai dari input
    const number = document.getElementById("number").value;
    const container = document.getElementById("table-container");

    // Reset isi tabel sebelumnya
    container.innerHTML = "";

    // Validasi input
    if (number < 1 || number > 10 || isNaN(number)) {
        container.innerHTML = "<p>Masukkan angka antara 1 hingga 10.</p>";
        return;
    }

    // Buat elemen tabel
    const table = document.createElement("table");

    for (let i = 1; i <= number; i++) {
        const row = document.createElement("tr");

        for (let j = 1; j <= number; j++) {
            const cell = document.createElement("td");
            cell.textContent = i * j; // Hasil perkalian
            row.appendChild(cell);
        }

        table.appendChild(row);
    }

    // Tambahkan tabel ke container
    container.appendChild(table);
}