#include <iostream>
using namespace std;

class Buku {
public:
    string nama;
    float panjang, lebar, luas;
    int harga, jumlahHalaman;

    Buku() {}
    Buku(string n, float p, float l, int h, int jh) {
        nama = n;
        panjang = p;
        lebar = l;
        harga = h;
        jumlahHalaman = jh;
        hitungLuas();
    }

    void hitungLuas() {
        luas = panjang * lebar;
    }

    float getLuas() const { return luas; }
    string getNama() const { return nama; }

    void tampilkanLuas() const {
        cout << "Nama: " << nama << ", Luas: " << luas << " cm�" << endl;
    }
};

// Struct untuk Node Linked List
struct Node {
    Buku data;
    Node* next;
};

// Tambah node di belakang
void tambahBelakang(Node*& head, Buku dataBuku) {
    Node* baru = new Node{dataBuku, nullptr};
    if (!head) {
        head = baru;
    } else {
        Node* temp = head;
        while (temp->next) {
            temp = temp->next;
        }
        temp->next = baru;
    }
}

// Tambah node di depan
void tambahDepan(Node*& head, Buku dataBuku) {
    Node* baru = new Node{dataBuku, head};
    head = baru;
}

// Tambah node di posisi tengah (posisi mulai dari 1)
void tambahTengah(Node*& head, Buku dataBuku, int posisi) {
    if (posisi <= 1 || head == nullptr) {
        tambahDepan(head, dataBuku);
        return;
    }

    Node* temp = head;
    for (int i = 1; i < posisi - 1 && temp->next != nullptr; i++) {
        temp = temp->next;
    }

    Node* baru = new Node{dataBuku, temp->next};
    temp->next = baru;
}

// Menampilkan isi linked list
void tampilkanList(Node* head) {
    Node* temp = head;
    while (temp) {
        temp->data.tampilkanLuas();
        temp = temp->next;
    }
}

// Searching berdasarkan nama buku
void search(Node* head, const string& namaCari) {
    Node* temp = head;
    while (temp) {
        if (temp->data.getNama() == namaCari) {
            cout << "Ditemukan! ";
            temp->data.tampilkanLuas();
            return;
        }
        temp = temp->next;
    }
    cout << "Buku dengan nama \"" << namaCari << "\" tidak ditemukan.\n";
}

// Sorting berdasarkan nama buku (bubble sort)
void sorting(Node*& head) {
    if (!head || !head->next) return;

    bool swapped;
    do {
        swapped = false;
        Node* curr = head;
        while (curr->next) {
            if (curr->data.getNama() > curr->next->data.getNama()) {
                swap(curr->data, curr->next->data);
                swapped = true;
            }
            curr = curr->next;
        }
    } while (swapped);
}


int main() {
    Node* head = nullptr;

    // Tambahkan data awal
    Buku semuaBuku[] = {
        Buku("Alkitab", 25, 18, 150000, 3000),
        Buku("Buku Tulis", 28, 20, 8000, 64),
        Buku("Buku Kalkulus", 23, 15, 130000, 600),
        Buku("Notebook", 10, 8, 25000, 50),
        Buku("Binder", 15, 10, 30000, 120)
    };

    for (int i = 0; i < 5; i++) {
        tambahBelakang(head, semuaBuku[i]);
    }

    cout << "== Daftar Awal Buku ==\n";
    tampilkanList(head);

    cout << "\n== Tambah di Depan (Kamus) ==\n";
    tambahDepan(head, Buku("Kamus", 20, 15, 50000, 500));
    tampilkanList(head);



    // Bersihkan memori
    while (head) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    return 0;
}
