#include <iostream>
using namespace std;

struct Node {
    int umur;
    Node* next;
};

Node *head = nullptr;

void mulaiLinkedlist(int umur) {
    head = new Node{umur, nullptr};
    cout << "Linked List mulai dari: " << umur << endl;
}

void tambahDepan(int umur) {
    Node* newNode = new Node{umur, head};
    head = newNode; // Update the head to the new node
    cout << "Ditambahkan didepan: " << umur << endl;
}

void tambahBelakang(int umur){
    Node* newNode = new Node;
    newNode->umur = umur;
    newNode ->next = nullptr;

    if(head==nullptr){
        head = newNode;
    }
    else{
    Node* temp = head;
    while (temp->next!=nullptr){
        temp=temp->next;
    }
    temp->next=newNode;
    }
}

void tambahTengah(int umur, int posisi) {
    if (posisi == 1 || head == nullptr) {
        tambahDepan(umur); // Use the function properly to add at the start
        return;
    }

    Node* temp = head;
    for (int i = 1; i < posisi - 1 && temp != nullptr; i++) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Posisi tidak ditemukan.\n";
        return;
    }

    Node* newNode = new Node{umur, temp->next};
    temp->next = newNode;
    cout << "Ditambahkan di tengah pada posisi " << posisi << ": " << umur << endl;
}

void tampilkanList() {
    Node* temp = head;
    cout << "Isi Linked List:\n";
    while (temp != nullptr) {
        cout << "Umur: " << temp->umur << endl;
        temp = temp->next;
    }
}

int main() {
    // Start a new linked list
    mulaiLinkedlist(21);

    // Add nodes at the front and middle
    tambahBelakang(65);
    tambahDepan(18);  // Add 18 at the front
    tambahTengah(28, 2); // Add 28 at position 2
    tambahTengah(35, 3); // Add 35 at position 3


    // Show the linked list
    tampilkanList();

    return 0;
}
