// judul : simulasi pendataan dengan variable biasa, array, linked list, double linkedlist
// modifikasi : 7 mei 2025
// author : alexander bangkit sp

#include <iostream>
using namespace std;

// Bagian 1: Pendataan Manual
void pendataanManual()
{
	cout << "=== Pendataan Manual ===\n";
	int sepatu1 = 42;
	int sepatu2 = 41;
	int sepatu3 = 43;
	int sepatu4 = 38;
	int sepatu5 = 40;
	int cari;


	// Menampilkan data
	cout << "Nomor sepatu yang tercatat:\n";
	cout << "Sepatu 1: " << sepatu1 << endl;
	cout << "Sepatu 2: " << sepatu2 << endl;
	cout << "Sepatu 3: " << sepatu3 << endl;
	cout << "Sepatu 4: " << sepatu4 << endl;
	cout << "Sepatu 5: " << sepatu5 << endl;

    cout << "Masukkan sepatu yang ingin di cari: ";cin >> cari;
        if(sepatu1 == cari || sepatu2 == cari || sepatu3 == cari || sepatu4 == cari || sepatu5 == cari){
        cout << "Nomor " << sepatu1 << " ditemukan" << endl;
        }
        /*else if (sepatu2 == cari){
            cout << "Nomor " << sepatu2 << " ditemukan" << endl ;
        }
         else if (sepatu3 == cari){
            cout << "Nomor " << sepatu3 << " ditemukan" << endl ;
        }
         else if (sepatu4 == cari){
            cout << "Nomor " << sepatu4 << " ditemukan" << endl ;
        }
         else if (sepatu5 == cari){
            cout << "Nomor " << sepatu5 << " ditemukan" << endl ;
        }*/
        else {
            cout << "Nomor sepatu tidak ditemukan" << endl;
        }
    }

// Bagian 2: Pendataan dengan Array
void pendataanArray()
{
	cout << "\n=== Pendataan dengan Array ===\n";
	int sepatu[5] = {42, 41, 43, 38, 44}; // Array menyimpan banyak nomor sepatu

	// Menampilkan data
	cout << "Nomor sepatu dalam array:\n";
	for (int i = 0; i < 5; i++)
	{
	    cout << "Sepatu ke-" << (i + 1) << ": " << sepatu[i] << endl;
	}

    bool ditemukan = false;
    int cari;
    cout << "Masukkan nomor sepatu: ";cin >> cari;
    for(int i = 0; i < 5; i++){
          if(sepatu[i] == cari){
            cout << "Nomor sepatu ditemukan" << endl;
            ditemukan = true;
          }
    }
    if(!ditemukan)
    {
        cout << "Nomor seapti tidak ditemukan" << endl;
    }

}

// Struktur untuk node linked list
struct Node
{
	int nomor;
	Node* next;
	Node* head;
};

// Bagian 3: Pendataan dengan Linked List
void pendataanLinkedList()
{
	cout << "\n=== Pendataan dengan Linked List ===\n";

	// Membuat tiga node
	Node* sepatu1 = new Node{42, nullptr};
	Node* sepatu2 = new Node{41, nullptr};
	Node* sepatu3 = new Node{43, nullptr};
	Node* sepatu4 = new Node{38, nullptr};
	Node* sepatu5 = new Node{40, nullptr};


	// Menghubungkan node
	sepatu1->next = sepatu2;
	sepatu2->next = sepatu3;
	sepatu3->next = sepatu4;
	sepatu4->next = sepatu5;
	// Menampilkan isi linked list
	Node* current = sepatu1;

	int nomor = 1;
	while (current != nullptr)
	{
		cout << "Sepatu ke-" << nomor << ": " << current->nomor << endl;
    		current = current->next;
    		nomor++;
	}

	cout << endl;

	int no;
	cout << "Masukkan nomor sepatu yang ingin di cari: "; cin >> no;
    Node* temp = sepatu1;
    while (temp != nullptr) {
        if (temp->nomor == no){
            cout << "Sepatu nomor " << no << " ditemukan" << endl;
            return;
        }
        temp = temp->next;
    }
    cout << "Data tidak ditemukan\n";
}




// Struktur untuk node double linked list
struct DNode
{
	int nomor;
	DNode* prev;
	DNode* next;
};

// Bagian 4: Pendataan dengan Double Linked List
void pendataanDoubleLinkedList()
{
	cout << "\n=== Pendataan dengan Double Linked List ===\n";

	// Membuat tiga node
	DNode* s1 = new DNode{42, nullptr, nullptr};
	DNode* s2 = new DNode{41, s1, nullptr};
	DNode* s3 = new DNode{43, s2, nullptr};
    DNode* s4 = new DNode{38, s3, nullptr};
    DNode* s5 = new DNode{40, s4, nullptr};
	s1->next = s2;
	s2->next = s3;
    s3->next = s4;
	s4->next = s5;
	// Menampilkan dari depan ke belakang
	cout << "Urutan dari depan:\n";
	DNode* maju = s1;
	int no = 1;
	while (maju != nullptr)
	{
    		cout << "Sepatu ke-" << no << ": " << maju->nomor << endl;
		    maju = maju->next;
    		no++;
	}

	// Menampilkan dari belakang ke depan
	cout << "Urutan dari belakang:\n";
	DNode* mundur = s5;
	no = 5;
	while (mundur != nullptr)
	{
		cout << "Sepatu ke-" << no << ": " << mundur->nomor << endl;
		mundur = mundur->prev;
	    	no=no-1;
}
}

// Fungsi utama
int main()
{
    pendataanManual();
    pendataanArray();
	pendataanLinkedList();
	pendataanDoubleLinkedList();
	return 0;
}
