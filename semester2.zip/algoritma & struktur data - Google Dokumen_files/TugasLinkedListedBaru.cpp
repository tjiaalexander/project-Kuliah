#include <iostream>
using namespace std;

class Buku {
public:
    string nama;
    float panjang, lebar, luas;
    int harga, jumlahHalaman;

    Buku() {}
    Buku(string n, float p, float l, int h, int jh) {
        nama = n;
        panjang = p;
        lebar = l;
        harga = h;
        jumlahHalaman = jh;
        hitungLuas();
    }

    void hitungLuas() {
        luas = panjang * lebar;
    }

    float getLuas() const { return luas; }
    string getNama() const { return nama; }

    void tampilkan() const {
        cout << nama << " | Luas: " << luas << " cm� | Harga: " << harga
             << " | Halaman: " << jumlahHalaman << endl;
    }
};

struct Node {
    Buku data;
    Node* next;
};

Node* head = nullptr;

// Tambah depan
void tambahDepan(Buku data) {
    Node* baru = new Node{data, head};
    head = baru;
}

// Tambah belakang
void tambahBelakang(Buku data) {
    Node* baru = new Node{data, nullptr};
    if (!head) head = baru;
    else {
        Node* temp = head;
        while (temp->next) temp = temp->next;
        temp->next = baru;
    }
}

// Tambah tengah (setelah posisi ke-n)
void tambahTengah(Buku data, int pos) {
    if (pos <= 0 || !head) {
        tambahDepan(data);
        return;
    }

    Node* temp = head;
    for (int i = 0; i < pos - 1 && temp->next; i++) {
        temp = temp->next;
    }

    Node* baru = new Node{data, temp->next};
    temp->next = baru;
}

// Tampilkan semua
void tampilkan() {
    Node* temp = head;
    int i = 1;
    while (temp) {
        cout << i++ << ". ";
        temp->data.tampilkan();
        temp = temp->next;
    }
}

// Ganti data
void gantiData(int pos, Buku dataBaru) {
    Node* temp = head;
    for (int i = 1; i < pos && temp; i++) {
        temp = temp->next;
    }
    if (temp) temp->data = dataBaru;
}

// Hapus node
void hapusData(int pos) {
    if (!head) return;

    if (pos == 1) {
        Node* hapus = head;
        head = head->next;
        delete hapus;
        return;
    }

    Node* temp = head;
    for (int i = 1; i < pos - 1 && temp->next; i++) {
        temp = temp->next;
    }

    if (temp->next) {
        Node* hapus = temp->next;
        temp->next = hapus->next;
        delete hapus;
    }
}

// Hitung panjang list
int hitungNode() {
    int count = 0;
    Node* temp = head;
    while (temp) {
        count++;
        temp = temp->next;
    }
    return count;
}

// Sorting (bubble sort linked list)
void sorting() {
    if (!head || !head->next) return;

    bool swapped;
    do {
        swapped = false;
        Node* curr = head;
        while (curr->next) {
            if (curr->data.getLuas() < curr->next->data.getLuas()) {
                swap(curr->data, curr->next->data);
                swapped = true;
            }
            curr = curr->next;
        }
    } while (swapped);
}

// Input buku
Buku inputBuku() {
    string nama;
    float panjang, lebar;
    int harga, jmlHalaman;

    cout << "Nama Buku: ";
    cin.ignore();
    getline(cin, nama);
    cout << "Panjang (cm): "; cin >> panjang;
    cout << "Lebar (cm): "; cin >> lebar;
    cout << "Harga: "; cin >> harga;
    cout << "Jumlah Halaman: "; cin >> jmlHalaman;

    return Buku(nama, panjang, lebar, harga, jmlHalaman);
}

int main() {
    int pilihan;

    do {
        cout << "\n==== MENU LINKED LIST BUKU ====\n";
        cout << "1. Tambah Depan\n2. Tambah Belakang\n3. Tambah Tengah\n";
        cout << "4. Ganti Data\n5. Hapus Data\n6. Tampilkan\n7. Sorting (Luas Desc)\n";
        cout << "0. Keluar\n";
        cout << "Pilih menu: ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                tambahDepan(inputBuku());
                break;
            case 2:
                tambahBelakang(inputBuku());
                break;
            case 3: {
                int pos;
                cout << "Masukkan posisi: ";
                cin >> pos;
                tambahTengah(inputBuku(), pos);
                break;
            }
            case 4: {
                int pos;
                cout << "Ganti data di posisi ke-: ";
                cin >> pos;
                gantiData(pos, inputBuku());
                break;
            }
            case 5: {
                int pos;
                cout << "Hapus data di posisi ke-: ";
                cin >> pos;
                hapusData(pos);
                break;
            }
            case 6:
                tampilkan();
                break;
            case 7:
                sorting();
                cout << "Data telah disorting berdasarkan luas buku (desc).\n";
                break;
            case 0:
                cout << "Program selesai.\n";
                break;
            default:
                cout << "Pilihan tidak valid!\n";
        }
    } while (pilihan != 0);

    // Hapus semua node
    while (head) {
        Node* hapus = head;
        head = head->next;
        delete hapus;
    }

    return 0;
}
