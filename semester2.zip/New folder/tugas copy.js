function cetakPerkalian() {
    let hasilDiv = document.getElementById('hasilTabel');
    hasilDiv.innerHTML = ""; // Bersihkan hasil sebelumnya

    let start = Number(document.getElementById('start').value);
    let end = Number(document.getElementById('end').value);

    // Validasi input
    if (isNaN(start) || isNaN(end) || start < 1 || end > 10 || start > end) {
        hasilDiv.innerHTML = "<p>Masukkan rentang angka yang valid (1-10) dengan <b>start</b> <= <b>end</b>.</p>";
        return;
    }

    // Kelompokkan tabel menjadi dua baris
    let row1 = []; // Baris pertama (1-5)
    let row2 = []; // Baris kedua (6-10)

    for (let i = start; i <= end; i++) {
        if (i <= 5) {
            row1.push(tampilTabel(i));
        } else {
            row2.push(tampilTabel(i));
        }
    }

    // Tampilkan tabel secara horizontal untuk setiap baris
    hasilDiv.innerHTML += `<div class="row">${row1.join('')}</div>`;
    hasilDiv.innerHTML += `<div class="row">${row2.join('')}</div>`;
}

function tampilTabel(angka) {
    let table = `<div style="margin: 10px;">
                    <strong>Tabel Perkalian ${angka}:</strong><br>`;
    table += "<table border='1' style='border-collapse: collapse; text-align: center; font-size: 14px; width: 150px;'>";

    for (let i = 1; i <= 10; i++) {
        table += `
            <tr>
                <td style="padding: 5px;">${angka} x ${i}</td>
                <td style="padding: 5px;">${angka * i}</td>
            </tr>`;
    }
    table += "</table></div>";
    return table;
}
